
const Blockchain = require('./blockchain');
const PubSub = require('./app/pubsub.pubnub');
const TransactionPool = require('./wallet/transaction-pool');
const Wallet = require('./wallet');
const TransactionMiner = require('./app/transaction-miner');

const prdurl="redis://:p3db1fdf142ab366b3f841c44d8bb9ed649a8f6125d76809435162a4add2001da@ec2-107-23-72-44.compute-1.amazonaws.com:16789";
const REDIS_URL = prdurl;
const DEFAULT_PORT = 3000;
const ROOT_NODE_ADDRESS = `http://localhost:${DEFAULT_PORT}`;

const blockchain = new Blockchain();
const transactionPool = new TransactionPool();
const wallet = new Wallet();
//const pubsub = new PubSub({ blockchain, transactionPool, redisUrl: REDIS_URL });
const pubsub = new PubSub({ blockchain, transactionPool, wallet }); // for PubNub
const transactionMiner = new TransactionMiner({ blockchain, transactionPool, wallet, pubsub });



export function appget_api_blocks(){
return JSON.stringify(blockchain.chain);
}
export function appget_api_blocks_length(){
  return JSON.stringify(blockchain.chain.length);
}


export function appget_api_blocks_id(id){
  const { length } = blockchain.chain;

  const blocksReversed = blockchain.chain.slice().reverse();

  let startIndex = (id-1) * 5;
  let endIndex = id * 5;

  startIndex = startIndex < length ? startIndex : length;
  endIndex = endIndex < length ? endIndex : length;

  return JSON.stringify(blocksReversed.slice(startIndex, endIndex));
}


export function apppost_api_mine(data){
  console.log("api/mine");
  console.log(data);
  blockchain.addBlock({ data });

  pubsub.broadcastChain();
  appget_api_blocks();
  
}

export function apppost_api_transact (body){

  const { amount, recipient } =JSON.parse(body);

  let transaction = transactionPool
    .existingTransaction({ inputAddress: wallet.publicKey });

  try {
    if (transaction) {
      transaction.update({ senderWallet: wallet, recipient, amount });
    } else {
      transaction = wallet.createTransaction({
        recipient,
        amount,
        chain: blockchain.chain
      });
    }
  } catch(error) {
    return JSON.stringify({ type: 'error', message: error.message });
  }

  transactionPool.setTransaction(transaction);

  pubsub.broadcastTransaction(transaction);

 return JSON.stringify({ type: 'success', transaction });
}



export function appget_api_transaction_pool_map() {
  return JSON.stringify(transactionPool.transactionMap);
}

export function appget_api_mine_transactions(){
  transactionMiner.mineTransactions();
  appget_api_blocks();

}
export function test(){
  
}
export function appget_api_wallet_info() {
  const address = wallet.publicKey;

  return JSON.stringify({
    address,
    balance: Wallet.calculateBalance({ chain: blockchain.chain, address })
  });
};

export function appget_api_known_addresses() {
  const addressMap = {};

  for (let block of blockchain.chain) {
    for (let transaction of block.data) {
      const recipient = Object.keys(transaction.outputMap);

      recipient.forEach(recipient => addressMap[recipient] = recipient);
    }
  }

  return JSON.stringify(Object.keys(addressMap));
}



const syncWithRootState = () => {
  let data=appget_api_blocks();
  const rootChain = JSON.parse(data);

  console.log('replace chain on a sync with', rootChain);
  blockchain.replaceChain(rootChain);
 /* request({ url: `${ROOT_NODE_ADDRESS}/api/blocks` }, (error, response, body) => {
    if (!error && response.statusCode === 200) {
      const rootChain = JSON.parse(body);

      console.log('replace chain on a sync with', rootChain);
      blockchain.replaceChain(rootChain);
    }
  });

  request({ url: `${ROOT_NODE_ADDRESS}/api/transaction-pool-map` }, (error, response, body) => {
    if (!error && response.statusCode === 200) {
      const rootTransactionPoolMap = JSON.parse(body);

      console.log('replace transaction pool map on a sync with', rootTransactionPoolMap);
      transactionPool.setMap(rootTransactionPoolMap);
    }
  });*/
  let body=appget_api_transaction_pool_map() ;
  const rootTransactionPoolMap = JSON.parse(body);

  console.log('replace transaction pool map on a sync with', rootTransactionPoolMap);
  transactionPool.setMap(rootTransactionPoolMap);

};





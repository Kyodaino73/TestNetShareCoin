import * as React from 'react';
import styles from './Blockchain.module.scss';
import { IBlockchainProps } from './IBlockchainProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Router, Switch, Route } from 'react-router-dom';
//const express=require ('express');
//import * as express from "express";
import { Link } from 'react-router-dom';

const logo: any = String(require('../components/assets/logo.png'));

export default class App extends React.Component<any, any> {
  constructor(props){
   super(props);
   this.state = { walletInfo: {} };
  // alert(this.props.url)
   
  }
   componentDidMount() {
   var data= this.props.api.appget_api_wallet_info();
   this.setState({ walletInfo: JSON.parse(data) });
   /* this.props.api.apiget_api_wallet_info()
      .then(response => response.json())
      .then(json => this.setState({ walletInfo: json }));*/
  }
  public render(): React.ReactElement<IBlockchainProps> {
    const { address, balance } = this.state.walletInfo;

    return (
      <div className='App'>
        <img className='logo' src={logo}></img>
        <br />
        <div>
          Welcome to the blockchain...
        </div>
        <br />
        <div><Link to='/blocks'>Blocks</Link></div>
        <div><Link to='/conduct-transaction'>Conduct a Transaction</Link></div>
        <div><Link to='/transaction-pool'>Transaction Pool</Link></div>
        <br />
        <div className='WalletInfo'>
          <div>Address: {address}</div>
          <div>Balance: {balance}</div>
        </div>
      </div>
    );
  
  }
}

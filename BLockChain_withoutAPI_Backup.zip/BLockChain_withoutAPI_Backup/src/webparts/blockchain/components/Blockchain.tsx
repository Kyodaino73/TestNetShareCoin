import * as React from 'react';
import styles from './Blockchain.module.scss';
import { IBlockchainProps } from './IBlockchainProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { Route, Link, Switch, BrowserRouter as Router,HashRouter } from 'react-router-dom'; 
import './blockchain.css';
import * as api from '../APIIndex';
//import history from './history';
import App from './App';
import Blocks from './Blocks';
import ConductTransaction from './ConductTransaction';
import TransactionPool from './TransactionPool';

//const EC = require('elliptic');
import * as elliptic from 'elliptic';

export default class Blockchain extends React.Component<IBlockchainProps, {}> {
  constructor(props){
   super(props);
  api.test();
   const EC = elliptic.ec;
   const ec = new EC('secp256k1');
    console.log(ec.genKeyPair());
    console.log(ec.genKeyPair().getPublic().encode('hex'));
  }
  redirect(hash){
    //var hash=  (window.location.hash);
    window.location.href=location.origin+location.pathname+hash;
  }
  public render(): React.ReactElement<IBlockchainProps> {
    return (
      <HashRouter  > 
      <div className={ `${styles.blockchain} blockchain` }>

    <Switch>
     <Route sensitive exact path='/'  render={(props) => (<App url={this.props.url} api={api}/>)} />
      <Route path='/Blocks' render={(props) => (<Blocks url={this.props.url} api={api}/> )} />
      <Route path='/conduct-transaction'  render={(props) => (<ConductTransaction url={this.props.url} api={api} />)} />
      <Route path='/transaction-pool'  render={(props) => (<TransactionPool url={this.props.url} api={api}/>)} />
    </Switch>

      </div>
        
   </HashRouter> 
    );
  }
}

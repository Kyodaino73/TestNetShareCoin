import * as React from 'react';
import { Button } from 'react-bootstrap';
import Transaction from './Transaction';
import { Link } from 'react-router-dom';
import history from './history';
const POLL_INERVAL_MS = 5000;
const url="https://whispering-earth-08745.herokuapp.com";
let fetchPoolMapInterval;
export default class TransactionPool extends React.Component<any, any> {
  constructor(props){
   super(props);
   this.state = { transactionPoolMap: {} };
   
  }
  fetchTransactionPoolMap = () => {
    let data=this.props.api.appget_api_transaction_pool_map();
    this.setState({ transactionPoolMap: JSON.parse(data) })
   
  }

  fetchMineTransactions = () => {
   let data=this.props.api.appget_api_mine_transactions();
   console.log(data);

   alert("success");
   window.location.href=location.origin+location.pathname+'#/blocks';
   //history.push('/blocks');
    /*fetch(`${url}/api/mine-transactions`)
      .then(response => {
        if (response.status === 200) {
          alert('success');
          history.push('/blocks');
        } else {
          alert('The mine-transactions block request did not complete.');
        }
      });*/
  }

  componentDidMount() {
    this.fetchTransactionPoolMap();
    
    fetchPoolMapInterval = setInterval(
      () => this.fetchTransactionPoolMap(),
      POLL_INERVAL_MS
    );
  }

  componentWillUnmount() {
    clearInterval(fetchPoolMapInterval);
  }

  public render(): React.ReactElement<any> {
    return (
    <div className='TransactionPool'>
    <div><Link to='/'>Home</Link></div>
    <h3>Transaction Pool</h3>
    {
      Object.values(this.state.transactionPoolMap).map( (transaction:any) => {
        return (
          <div key={transaction.id}>
            <hr />
            <Transaction transaction={transaction} />
          </div>
        )
      })
    }
    <hr />
    <Button
      bsStyle="danger"
      onClick={this.fetchMineTransactions}
    >
      Mine the Transactions
    </Button>
  </div>
);
  
  }
}

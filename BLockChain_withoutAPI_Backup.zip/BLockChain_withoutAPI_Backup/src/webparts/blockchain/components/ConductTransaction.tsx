import * as React from 'react';
import styles from './Blockchain.module.scss';
import { FormGroup, FormControl, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
//import history from './history';



//const url="https://whispering-earth-08745.herokuapp.com";
export default class ConductTransaction extends React.Component<any, any> {
  constructor(props){
   super(props);
   this.state = { recipient: '', amount: 0, knownAddresses: [] };
   
  }
  componentDidMount() {
   let data= this.props.api.appget_api_known_addresses();
   this.setState({ knownAddresses: JSON.parse(data) })
  
  }

  updateRecipient = event => {
    this.setState({ recipient: event.target.value });
  }

  updateAmount = event => {
    this.setState({ amount: Number(event.target.value) });
  }

  conductTransaction = () => {
    const { recipient, amount } = this.state;
    if(recipient !="" && amount !=""){
    let data=this.props.api.apppost_api_transact(JSON.stringify({ recipient, amount }));
    console.log(data);
    alert("success");
    window.location.href=location.origin+location.pathname+'#/transaction-pool';
    }
    else{
      alert("Enter the recipient and amount");
    }
   //this.props.history.push('#/transaction-pool');
   
  }

  public render(): React.ReactElement<any> {
    return (
      <div className='ConductTransaction'>
        <Link to='/'>Home</Link>
        <h3>Conduct a Transaction</h3>
        <br />
        <h4>Known Addresses</h4>
        {
          this.state.knownAddresses.map(knownAddress => {
            return (
              <div key={knownAddress}>
                <div>{knownAddress}</div>
                <br />
              </div>
            );
          })
        }
        <br />
        <FormGroup>
          <FormControl
            input='text'
            placeholder='recipient'
            value={this.state.recipient}
            onChange={this.updateRecipient}
          />
        </FormGroup>
        <FormGroup>
          <FormControl
            input='number'
            placeholder='amount'
            value={this.state.amount}
            onChange={this.updateAmount}
          />
        </FormGroup>
        <div>
          <Button
            bsStyle="danger"
            onClick={this.conductTransaction}
          >
            Submit
          </Button>
        </div>
      </div>
    );
  
  }
}

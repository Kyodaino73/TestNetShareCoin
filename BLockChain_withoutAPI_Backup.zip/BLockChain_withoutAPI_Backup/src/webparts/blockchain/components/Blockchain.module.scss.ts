/* tslint:disable */
require("./Blockchain.module.css");
const styles = {
  blockchain: 'blockchain_56cf90a8',
  container: 'container_56cf90a8',
  row: 'row_56cf90a8',
  column: 'column_56cf90a8',
  'ms-Grid': 'ms-Grid_56cf90a8',
  title: 'title_56cf90a8',
  subTitle: 'subTitle_56cf90a8',
  description: 'description_56cf90a8',
  button: 'button_56cf90a8',
  label: 'label_56cf90a8'
};

export default styles;
/* tslint:enable */
import * as React from 'react';
import styles from './Blockchain.module.scss';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import Block from './Block';
const url="https://whispering-earth-08745.herokuapp.com";
export default class Blocks extends React.Component<any, any> {
  constructor(props){
   super(props);
   this.state = { blocks: [], paginatedId: 1, blocksLength: 0 };
  }
  
  componentDidMount() {
    let data=this.props.api.appget_api_blocks_length();
    this.setState({ blocksLength:JSON.parse(data) })

    this.fetchPaginatedBlocks(this.state.paginatedId)();
  }

  fetchPaginatedBlocks = paginatedId => () => {
   let data=this.props.api.appget_api_blocks_id(paginatedId);
   this.setState({ blocks: JSON.parse(data) });
   
  }
  public render(): React.ReactElement<any> {
    console.log('this.state', this.state);
      
    return (
      <div>
        <div><Link to='/'>Home</Link></div>
        <h3>Blocks</h3>
        <div>
          {
            [...Array(Math.ceil(this.state.blocksLength/5)).keys()].map(key => {
              const paginatedId = key+1;

              return (
                <span key={key} onClick={this.fetchPaginatedBlocks(paginatedId)}>
                  <Button bsSize="small" bsStyle="danger">
                    {paginatedId}
                  </Button>{' '}
                </span>
              )
            })
          }
        </div>
        {
          this.state.blocks.map(block => {
            return (
              <Block key={block.hash} block={block} />
            );
          })
        }
      </div>
    );
  
  }
}

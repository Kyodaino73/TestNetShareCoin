export interface IBlockchainProps {
  description: string;
  url:string;
}

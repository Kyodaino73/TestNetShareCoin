declare interface IBlockchainWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BlockchainWebPartStrings' {
  const strings: IBlockchainWebPartStrings;
  export = strings;
}

import * as React from 'react';
export default class ConductTransaction extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): void;
    updateRecipient: (event: any) => void;
    updateAmount: (event: any) => void;
    conductTransaction: () => void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=ConductTransaction.d.ts.map
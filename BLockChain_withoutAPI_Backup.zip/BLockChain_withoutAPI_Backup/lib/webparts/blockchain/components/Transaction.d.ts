declare const Transaction: ({ transaction }: {
    transaction: any;
}) => JSX.Element;
export default Transaction;
//# sourceMappingURL=Transaction.d.ts.map
import * as React from 'react';
export default class Blocks extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): void;
    fetchPaginatedBlocks: (paginatedId: any) => () => void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=Blocks.d.ts.map
import * as React from 'react';
import { IBlockchainProps } from './IBlockchainProps';
import './blockchain.css';
export default class Blockchain extends React.Component<IBlockchainProps, {}> {
    constructor(props: any);
    redirect(hash: any): void;
    render(): React.ReactElement<IBlockchainProps>;
}
//# sourceMappingURL=Blockchain.d.ts.map
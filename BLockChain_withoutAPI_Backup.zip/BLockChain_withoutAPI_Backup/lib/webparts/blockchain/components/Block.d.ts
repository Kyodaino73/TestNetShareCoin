import * as React from 'react';
export default class Block extends React.Component<any, any> {
    constructor(props: any);
    toggleTransaction: () => void;
    readonly displayTransaction: JSX.Element;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=Block.d.ts.map
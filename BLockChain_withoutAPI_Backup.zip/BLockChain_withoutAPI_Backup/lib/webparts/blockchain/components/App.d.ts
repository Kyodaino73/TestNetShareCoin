import * as React from 'react';
import { IBlockchainProps } from './IBlockchainProps';
export default class App extends React.Component<any, any> {
    constructor(props: any);
    componentDidMount(): void;
    render(): React.ReactElement<IBlockchainProps>;
}
//# sourceMappingURL=App.d.ts.map
import * as React from 'react';
export default class TransactionPool extends React.Component<any, any> {
    constructor(props: any);
    fetchTransactionPoolMap: () => void;
    fetchMineTransactions: () => void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=TransactionPool.d.ts.map
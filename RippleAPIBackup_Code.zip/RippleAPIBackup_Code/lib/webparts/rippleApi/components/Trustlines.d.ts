import * as React from 'react';
export default class Trustlines extends React.Component<any, any> {
    constructor(props: any);
    verifyTransaction(hash: any, options: any): any;
    submitTransaction(lastClosedLedgerVersion: any, prepared: any, secret: any): any;
    setTrustlines(api: any): Promise<void>;
    getTrustlines(): void;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=Trustlines.d.ts.map
import * as React from 'react';
import { IRippleApiProps } from './IRippleApiProps';
import 'react-toastify/dist/ReactToastify.css';
export default class RippleApi extends React.Component<IRippleApiProps, any> {
    constructor(props: any);
    run(): Promise<void>;
    account_currencies(): void;
    addTrustLines(): void;
    verifyTransaction(hash: any, options: any): any;
    private submitTransaction;
    private _hidePanel;
    private _showPanel;
    private _textIssuedCurrencyChanged;
    private _textIssuerChanged;
    private _textLimitChanged;
    private _textFromAddressChanged;
    private _textSecretChanged;
    showToast(msg: any, type: any): void;
    render(): React.ReactElement<IRippleApiProps>;
}
//# sourceMappingURL=RippleApi.d.ts.map
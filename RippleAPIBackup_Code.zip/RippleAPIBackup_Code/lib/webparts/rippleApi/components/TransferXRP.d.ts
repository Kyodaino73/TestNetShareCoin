import * as React from 'react';
export default class TransferXRP extends React.Component<any, any> {
    constructor(props: any);
    sendXRP(): Promise<void>;
    transact(api: any): Promise<void>;
    verifyTransaction(hash: any, options: any): any;
    private submitTransaction;
    private _textToAddressChanged;
    private _textAmountChanged;
    private _textCurrencyChanged;
    private _transferAmtClicked;
    findpath(): any;
    render(): React.ReactElement<any>;
}
//# sourceMappingURL=TransferXRP.d.ts.map
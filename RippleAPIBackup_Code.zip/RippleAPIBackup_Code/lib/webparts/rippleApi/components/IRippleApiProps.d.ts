export interface IRippleApiProps {
    description: string;
}
//# sourceMappingURL=IRippleApiProps.d.ts.map
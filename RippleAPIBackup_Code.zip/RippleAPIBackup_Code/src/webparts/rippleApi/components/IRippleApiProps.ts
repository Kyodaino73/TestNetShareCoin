export interface IRippleApiProps {
  description: string;
}

/* tslint:disable */
require("./RippleApi.module.css");
const styles = {
  addTrustbtn: 'addTrustbtn_db80e5ea',
  rippleApi: 'rippleApi_db80e5ea',
  container: 'container_db80e5ea',
  grid: 'grid_db80e5ea',
  row: 'row_db80e5ea',
  twocolumnlayout: 'twocolumnlayout_db80e5ea',
  'ms-Grid': 'ms-Grid_db80e5ea',
  onecolumnlayout: 'onecolumnlayout_db80e5ea',
  AppName: 'AppName_db80e5ea',
  sectionheading: 'sectionheading_db80e5ea',
  labelheading: 'labelheading_db80e5ea',
  addtrust: 'addtrust_db80e5ea',
  refresh: 'refresh_db80e5ea',
  trustlines: 'trustlines_db80e5ea',
  theading: 'theading_db80e5ea',
  trustheading: 'trustheading_db80e5ea',
  column: 'column_db80e5ea',
  title: 'title_db80e5ea',
  subTitle: 'subTitle_db80e5ea',
  description: 'description_db80e5ea',
  button: 'button_db80e5ea',
  label: 'label_db80e5ea'
};

export default styles;
/* tslint:enable */